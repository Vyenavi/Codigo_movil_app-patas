package com.app.apppatas.publicar.modelo;

public class Tipo_mascota {
    int idtipo_mascota;
    String tipo_mascota_especie;
}
