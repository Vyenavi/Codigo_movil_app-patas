package com.app.apppatas.publicar.adaptadores;

public class PublicacionAdaptador {
}
