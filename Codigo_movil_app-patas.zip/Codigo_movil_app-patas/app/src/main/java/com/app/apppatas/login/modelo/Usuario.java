package com.app.apppatas.login.modelo;

public class Usuario {
}
