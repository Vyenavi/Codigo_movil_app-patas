package com.app.apppatas.encontrar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.app.apppatas.R;

public class TeEncontreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_te_encontre);
    }
}
