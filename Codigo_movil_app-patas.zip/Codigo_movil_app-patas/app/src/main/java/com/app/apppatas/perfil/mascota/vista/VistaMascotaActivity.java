package com.app.apppatas.perfil.mascota.vista;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.app.apppatas.R;

public class VistaMascotaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_mascota);
    }
}
