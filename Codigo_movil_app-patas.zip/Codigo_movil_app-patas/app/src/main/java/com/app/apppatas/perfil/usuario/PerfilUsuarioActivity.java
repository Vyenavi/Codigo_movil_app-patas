package com.app.apppatas.perfil.usuario;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.app.apppatas.R;

public class PerfilUsuarioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_usuario);
    }
}
