package com.app.apppatas.login.olvide_contraseña;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.app.apppatas.R;

public class OlvideContrasenaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_olvide_contrasena);
    }
}
